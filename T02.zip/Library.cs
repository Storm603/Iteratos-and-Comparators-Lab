﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparators
{
    public class Library : IEnumerable<Book>
    {
        private List<Book> Books;

        public Library(params Book[] books)
        {
            Books = new List<Book>(books);
        }

        public IEnumerator<Book> GetEnumerator()
        {
            return new LibraryIterator(Books);
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        private class LibraryIterator : IEnumerator<Book>
        {
            public bool MoveNext()
            {
                currentIndex++;
                if (currentIndex < Books.Count)
                {
                    return true;
                }

                return false;
            }

            public LibraryIterator(IEnumerable<Book> books)
            {
                Books = new List<Book>(books);
                this.Reset();
            }
            public void Reset()
            {
                currentIndex = -1;
            }

            private readonly List<Book> Books;
            private int currentIndex;

            public Book Current => Books[currentIndex];

            object? IEnumerator.Current => Current;

            public void Dispose()
            {
            }
        }
    }
}
